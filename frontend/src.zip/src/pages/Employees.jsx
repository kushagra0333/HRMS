export default function Employees() {
  return (
    <div className="w-full">
      <h1 className="text-2xl font-semibold">Employees</h1>
      <p className="text-gray-500">Manage employees here</p>
    </div>
  );
}
