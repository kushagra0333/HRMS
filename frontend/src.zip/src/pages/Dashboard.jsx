export default function Dashboard() {
  return (
    <div className="w-full">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      <p className="text-gray-500">Overview of HRMS</p>
    </div>
  );
}
