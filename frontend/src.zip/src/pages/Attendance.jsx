export default function Attendance() {
  return (
    <div className="w-full">
      <h1 className="text-2xl font-semibold">Attendance</h1>
      <p className="text-gray-500">Attendance records</p>
    </div>
  );
}
